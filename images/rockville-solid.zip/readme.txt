Note of the author
This font is 100% FREE TO USE.
But any donation are very appreciated.

Paypal account for donation : damarkurung8@gmail.com

Please visit our store for more great fonts:
https://fontbundles.net/damarletter

If you have any questions, more informations and other license
Please contact me via email
damarkurung8@gmail.com